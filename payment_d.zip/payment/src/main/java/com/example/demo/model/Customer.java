package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	private String customerId;
	private String acountHolderName, customerAddress, customerCity, customerType;
	private String overdraftFlag;
	private Double balance;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getAcountHolderName() {
		return acountHolderName;
	}

	public void setAcountHolderName(String acountHolderName) {
		this.acountHolderName = acountHolderName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerCity() {
		return customerCity;
	}

	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getOverdraftFlag() {
		return overdraftFlag;
	}

	public void setOverdraftFlag(String overdraftFlag) {
		this.overdraftFlag = overdraftFlag;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", acountHolderName=" + acountHolderName + ", customerAddress="
				+ customerAddress + ", customerCity=" + customerCity + ", customerType=" + customerType
				+ ", overdraftFlag=" + overdraftFlag + ", Balance=" + balance + "]";
	}

}
