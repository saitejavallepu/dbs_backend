package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Message;
import com.example.demo.repository.MessageRepository;

@RestController
@RequestMapping("/message")
@CrossOrigin(origins = "http://localhost:3000")
public class MessageController {
	@Autowired
	private MessageRepository messageRepository;

	// Provides List of all Message information
	@GetMapping("/")
	public List<Message> listmessage() {
		return messageRepository.findAll();
	}

	// Adds Message Details to the Repository
	@PostMapping("/")
	public Message addMessage(@RequestBody Message message) {
		return messageRepository.save(message);
	}
}
