package com.example.demo.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import org.springframework.data.annotation.CreatedDate;

@Entity
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer transactionId;
	private String receiverAccountHolderNumber, receiverAccountHolderName;
	private Integer amount;
	private String transferDate;

	@ManyToOne
	private Message message; // many to one relation with Transaction to message
	@ManyToOne
	private Transfertypes transfertypes; // many to one relation with Transaction to TransactionTypes
	@ManyToOne
	private Bank senderbicBank; // many to one relation with Transaction to Bank
	@ManyToOne
	private Bank receiverbicBank; // many to one relation with Transaction to Bank
	@ManyToOne
	private Customer customer; // many to one relation with Transaction to Customer

	// Getters and Setters Methods
	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public String getReceiverAccountHolderNumber() {
		return receiverAccountHolderNumber;
	}

	public void setReceiverAccountHolderNumber(String receiverAccountHolderNumber) {
		this.receiverAccountHolderNumber = receiverAccountHolderNumber;
	}

	public String getReceiverAccountHolderName() {
		return receiverAccountHolderName;
	}

	public void setReceiverAccountHolderName(String receiverAccountHolderName) {
		this.receiverAccountHolderName = receiverAccountHolderName;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public String getTransferDate() {
		return transferDate;
	}

	public void setTransferDate(String transferDate) {
		this.transferDate = transferDate;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public Transfertypes getTransfertypes() {
		return transfertypes;
	}

	public void setTransfertypes(Transfertypes transfertypes) {
		this.transfertypes = transfertypes;
	}

	public Bank getSenderbicBank() {
		return senderbicBank;
	}

	public void setSenderbicBank(Bank senderbicBank) {
		this.senderbicBank = senderbicBank;
	}

	public Bank getReceiverbicBank() {
		return receiverbicBank;
	}

	public void setReceiverbicBank(Bank receiverbicBank) {
		this.receiverbicBank = receiverbicBank;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	// ToString Method
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", receiverAccountHolderNumber="
				+ receiverAccountHolderNumber + ", receiverAccountHolderName=" + receiverAccountHolderName + ", amount="
				+ amount + ", transferDate=" + transferDate + ", message=" + message + ", transfertypes="
				+ transfertypes + ", senderbicBank=" + senderbicBank + ", receiverbicBank=" + receiverbicBank
				+ ", customer=" + customer + "]";
	}

}
