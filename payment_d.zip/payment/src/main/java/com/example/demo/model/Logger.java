package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Logger {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer loggerId;
	private String screenname, action, ipaddress;

	@ManyToOne
	private Employee employee; // many to one relation with Logger to Employee

	@ManyToOne
	private Customer customer; // many to one relation with Logger to Customer

	// Getters and Setters Methods
	public Integer getLoggerId() {
		return loggerId;
	}

	public void setLoggerId(Integer loggerId) {
		this.loggerId = loggerId;
	}

	public String getScreenname() {
		return screenname;
	}

	public void setScreenname(String screenname) {
		this.screenname = screenname;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getIpaddress() {
		return ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	// ToString Method
	@Override
	public String toString() {
		return "Logger [loggerId=" + loggerId + ", screenname=" + screenname + ", action=" + action + ", ipaddress="
				+ ipaddress + ", employee=" + employee + ", customer=" + customer + "]";
	}

}
