package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.Transfertypes;
import com.example.demo.repository.TransfertypesRepository;

@RestController
@RequestMapping("/transactiontype")
@CrossOrigin(origins = "http://localhost:3000")
public class TransfertypesController {
	@Autowired
	public TransfertypesRepository transfertypesRepository;

	// Provides List of all TransferTypes Information
	@GetMapping("/")
	public List<Transfertypes> iisttransfer() {
		return transfertypesRepository.findAll();
	}

	// Adds TransferType Details to the Repository
	@PostMapping("/")
	public Transfertypes addTransfertypes(@RequestBody Transfertypes transfertypes) {
		return transfertypesRepository.save(transfertypes);
	}
}
