package com.example.demo.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Customer;
import com.example.demo.model.Transaction;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.TransactionRepository;

@RestController
@RequestMapping("/transaction")
@CrossOrigin(origins = "http://localhost:3000")
public class TransactionController {
	@Autowired
	private TransactionRepository transactionRepository;
	@Autowired
	private CustomerRepository customerRepository;

	// Provides List of all Transaction Details
	@GetMapping("/")
	public List<Transaction> listcurrency() {
		return transactionRepository.findAll();
	}

	// Adds Transaction Details to the Repository
	@PostMapping("/")
	public Transaction addTransaction(@RequestBody Transaction transaction) {

		// Customer customer = transaction.getCustomer();
		Integer amtString = transaction.getAmount();
		Optional<Customer> customerPresent = customerRepository.findById(transaction.getCustomer().getCustomerId());
		Customer customerDeatilsCustomer = customerRepository
				.findBycustomerId(transaction.getCustomer().getCustomerId());
		if (customerPresent != null) {
			if (customerDeatilsCustomer.getOverdraftFlag() == "yes") {
				customerDeatilsCustomer.setBalance(customerDeatilsCustomer.getBalance() - Double.valueOf(amtString));
				customerRepository.save(customerDeatilsCustomer);
			} else {
				if (customerDeatilsCustomer.getBalance() > Double.valueOf(amtString)) {
					customerDeatilsCustomer
							.setBalance(customerDeatilsCustomer.getBalance() - Double.valueOf(amtString) - (Double.valueOf(amtString)* 0.025));
					customerRepository.save(customerDeatilsCustomer);
				} else {
					// add condition ;
				}
			}
		}

		return transactionRepository.save(transaction);
	}

	@GetMapping("/{id}")
	public Transaction listgeTransactions(@PathVariable Integer id) {
		return transactionRepository.findById(id).get();
	}

	@DeleteMapping("/transactiondelete/{id}")
	public void deletetransaction(@PathVariable Integer id) {
		transactionRepository.deleteById(id);
	}
}
