package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Customeruser {
	@Id
	private Integer usedId;
	private String userName, userPassword;

	@ManyToOne
	private Customer customer; // many to one relation with CustomerUser and Customer

	// Getters and Setters Methods
	public Integer getUsedId() {
		return usedId;
	}

	public void setUsedId(Integer usedId) {
		this.usedId = usedId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	// ToString Method
	@Override
	public String toString() {
		return "Customeruser [usedId=" + usedId + ", userName=" + userName + ", userPassword=" + userPassword
				+ ", customer=" + customer + "]";
	}

}
