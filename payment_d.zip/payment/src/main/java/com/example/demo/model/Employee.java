package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {
	@Id
	private int employeId;
	private String employeeName, employeePassword;

	// Getters and Setters Methods
	public int getEmployeId() {
		return employeId;
	}

	public void setEmployeId(int employeId) {
		this.employeId = employeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeePassword() {
		return employeePassword;
	}

	public void setEmployeePassword(String employeePassword) {
		this.employeePassword = employeePassword;
	}

	// ToString Method
	@Override
	public String toString() {
		return "Employee [employeId=" + employeId + ", employeeName=" + employeeName + ", employeePassword="
				+ employeePassword + "]";
	}

}
