package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.Customeruser;
import com.example.demo.repository.CustomeruserRepository;

@RestController
@RequestMapping("/customeruser")
@CrossOrigin(origins = "http://localhost:3000")
public class CustomeruserController {
	@Autowired
	private CustomeruserRepository customeruserRepository;

	// Provides List of all CustomerUser Details
	@GetMapping("/")
	public List<Customeruser> listcustomerusers() {
		return customeruserRepository.findAll();
	}

	// Adds CustomerUser Details to the Repository
	@PostMapping("/")
	public Customeruser addCustomeruser(@RequestBody Customeruser customeruser) {
		return customeruserRepository.save(customeruser);
	}
}
