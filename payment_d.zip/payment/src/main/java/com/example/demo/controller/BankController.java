package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.Bank;
import com.example.demo.repository.BankRepository;

@RestController
@RequestMapping("/bank")
@CrossOrigin(origins = "http://localhost:3000")
public class BankController {

	@Autowired
	private BankRepository bankRepository;

	// Provides List of all Banks Details
	@GetMapping("/")
	public List<Bank> listBanks() {
		return bankRepository.findAll();
	}

	// Adds Bank Details to the Repository
	@PostMapping("/")
	public Bank addbank(@RequestBody Bank bank) {
		return bankRepository.save(bank);
	}
}
